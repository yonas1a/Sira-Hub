# ─────────────────────────────────────────────
#  bot.py  —  Telegram bot + APScheduler
#  Run with:  python bot.py
# ─────────────────────────────────────────────
import asyncio
import logging
from datetime import datetime

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    ConversationHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from config import (
    BOT_TOKEN,
    BASE_URL,
    MAX_JOBS_PER_ALERT,
    SCRAPE_INTERVAL_HOURS,
    START_PAGE,
    END_PAGE,
)
from db import (
    add_subscriber,
    clear_filter,
    get_active_subscribers,
    get_filter,
    get_stats,
    init_db,
    remove_subscriber,
    search_jobs,
    upsert_filter,
)
from scraper import scrape_all_pages

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ── Conversation states ───────────────────────
KEYWORD, LOCATION, EXPERIENCE = range(3)


# ── Message formatter ─────────────────────────

def _fmt(job: dict | tuple) -> str:
    """Format a job dict (or legacy tuple) into a Telegram Markdown message."""
    if isinstance(job, (list, tuple)):
        keys = ["title", "company", "location", "experience", "description", "deadline", "url"]
        job  = dict(zip(keys, job))

    desc = job.get("description", "")
    if len(desc) > 160:
        desc = desc[:157] + "…"

    lines = [
        f"💼 *{job['title']}*",
        f"🏢 {job['company']}",
        f"📍 {job['location']}",
        f"🎓 {job['experience']}",
        f"⏳ {job['deadline']}",
    ]
    if desc:
        lines.append(f"📝 _{desc}_")
    lines.append(f"[View Job ➜]({job['url']})")
    return "\n".join(lines)


# ── Helpers ───────────────────────────────────

def _matches_filter(job: dict, f: dict | None) -> bool:
    """Return True if the job satisfies the subscriber's filter."""
    if not f:
        return True

    kw  = (f.get("keyword")    or "").lower()
    loc = (f.get("location")   or "").lower()
    exp = (f.get("experience") or "").lower()

    if kw and kw not in (job["title"] + job["company"] + job["description"]).lower():
        return False
    if loc and loc not in job["location"].lower():
        return False
    if exp and exp not in job["experience"].lower():
        return False
    return True


# ── Command handlers ──────────────────────────

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id  = update.effective_chat.id
    username = update.effective_user.username or update.effective_user.first_name
    add_subscriber(chat_id, username)

    await update.message.reply_text(
        "👋 *Welcome to Hahu Jobs Bot!*\n\n"
        "I automatically scrape [hahu.jobs](https://www.hahu.jobs) every "
        f"{SCRAPE_INTERVAL_HOURS} hours and push new listings straight to you.\n\n"
        "📋 *Available Commands*\n"
        "/filter       — Set keyword, location & experience filters\n"
        "/myfilter     — View your current filters\n"
        "/clearfilter  — Remove all filters\n"
        "/latestjobs   — Show the 10 latest matching jobs\n"
        "/stats        — Bot & database statistics\n"
        "/stop         — Unsubscribe from alerts",
        parse_mode="Markdown",
        disable_web_page_preview=True,
    )


async def cmd_stop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    remove_subscriber(update.effective_chat.id)
    await update.message.reply_text(
        "😢 You've been unsubscribed. Send /start any time to re-subscribe."
    )


async def cmd_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    s = get_stats()
    await update.message.reply_text(
        "📊 *Bot Statistics*\n\n"
        f"💼 Total jobs in DB:      {s['total_jobs']}\n"
        f"📅 Jobs added today:       {s['jobs_today']}\n"
        f"👥 Active subscribers:    {s['active_subscribers']}",
        parse_mode="Markdown",
    )


async def cmd_myfilter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    f = get_filter(update.effective_chat.id)
    if not f or not any(f.values()):
        await update.message.reply_text(
            "You have no active filters — you receive *all* new jobs.\n"
            "Use /filter to set one.",
            parse_mode="Markdown",
        )
        return
    await update.message.reply_text(
        "🔍 *Your Active Filters*\n\n"
        f"🔑 Keyword:    {f['keyword']    or 'Any'}\n"
        f"📍 Location:   {f['location']   or 'Any'}\n"
        f"🎓 Experience: {f['experience'] or 'Any'}\n\n"
        "Use /clearfilter to reset them.",
        parse_mode="Markdown",
    )


async def cmd_clearfilter(update: Update, context: ContextTypes.DEFAULT_TYPE):
    clear_filter(update.effective_chat.id)
    await update.message.reply_text("✅ Filters cleared. You'll now receive all job alerts.")


async def cmd_latestjobs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    f    = get_filter(update.effective_chat.id) or {}
    jobs = search_jobs(
        keyword    = f.get("keyword"),
        location   = f.get("location"),
        experience = f.get("experience"),
        limit      = 10,
    )
    if not jobs:
        await update.message.reply_text(
            "No jobs found matching your filters.\n"
            "Try /clearfilter to broaden your search."
        )
        return

    await update.message.reply_text(
        f"📋 *Latest {len(jobs)} Matching Jobs*", parse_mode="Markdown"
    )
    for job in jobs:
        await update.message.reply_text(
            _fmt(job), parse_mode="Markdown", disable_web_page_preview=True
        )
        await asyncio.sleep(0.3)


# ── /filter conversation ──────────────────────

async def filter_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🔍 *Filter Setup — Step 1 of 3*\n\n"
        "Enter a *keyword* to match against job title, company, or description.\n"
        "_(e.g. `Python`, `Marketing`, `Engineer`)_\n\n"
        "Type `skip` to leave this filter empty.",
        parse_mode="Markdown",
    )
    return KEYWORD


async def filter_keyword(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    context.user_data["kw"] = None if text.lower() == "skip" else text
    await update.message.reply_text(
        "📍 *Step 2 of 3 — Location*\n\n"
        "Enter a location to filter by _(e.g. `Addis Ababa`, `Remote`)_.\n"
        "Type `skip` to leave empty.",
        parse_mode="Markdown",
    )
    return LOCATION


async def filter_location(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    context.user_data["loc"] = None if text.lower() == "skip" else text
    await update.message.reply_text(
        "🎓 *Step 3 of 3 — Experience Level*\n\n"
        "Enter an experience filter _(e.g. `0-2 years`, `Senior`, `Entry`)_.\n"
        "Type `skip` to leave empty.",
        parse_mode="Markdown",
    )
    return EXPERIENCE


async def filter_experience(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    context.user_data["exp"] = None if text.lower() == "skip" else text

    kw  = context.user_data.get("kw")
    loc = context.user_data.get("loc")
    exp = context.user_data.get("exp")

    upsert_filter(update.effective_chat.id, keyword=kw, location=loc, experience=exp)

    await update.message.reply_text(
        "✅ *Filters saved!*\n\n"
        f"🔑 Keyword:    {kw  or 'Any'}\n"
        f"📍 Location:   {loc or 'Any'}\n"
        f"🎓 Experience: {exp or 'Any'}\n\n"
        "You'll only receive alerts that match these filters.\n"
        "Use /latestjobs to browse matching jobs right now.",
        parse_mode="Markdown",
    )
    return ConversationHandler.END


async def filter_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Filter setup cancelled.")
    return ConversationHandler.END


# ── Scheduled scrape & broadcast ─────────────

async def scheduled_scrape(app: Application):
    logger.info("⏰ Scheduled scrape started")

    try:
        new_jobs = await asyncio.to_thread(scrape_all_pages, START_PAGE, END_PAGE, BASE_URL)
    except Exception as e:
        logger.error(f"Scrape failed: {e}")
        return

    if not new_jobs:
        logger.info("No new jobs — skipping broadcast")
        return

    subscribers = get_active_subscribers()
    logger.info(f"Broadcasting to {len(subscribers)} subscribers…")

    for chat_id in subscribers:
        try:
            f       = get_filter(chat_id)
            matches = [j for j in new_jobs if _matches_filter(j, f)]

            if not matches:
                continue

            capped = matches[:MAX_JOBS_PER_ALERT]
            suffix = f" (showing {MAX_JOBS_PER_ALERT} of {len(matches)})" if len(matches) > MAX_JOBS_PER_ALERT else ""

            await app.bot.send_message(
                chat_id    = chat_id,
                text       = f"🔔 *{len(matches)} New Job{'s' if len(matches) != 1 else ''} Found{suffix}!*",
                parse_mode = "Markdown",
            )

            for job in capped:
                await app.bot.send_message(
                    chat_id             = chat_id,
                    text                = _fmt(job),
                    parse_mode          = "Markdown",
                    disable_web_page_preview = True,
                )
                await asyncio.sleep(0.35)  # stay well below Telegram rate limits

        except Exception as e:
            logger.error(f"Failed to notify chat {chat_id}: {e}")


# ── Entry point ───────────────────────────────

def main():
    init_db()

    app = Application.builder().token(BOT_TOKEN).build()

    # Register /filter as a multi-step conversation
    filter_conv = ConversationHandler(
        entry_points = [CommandHandler("filter", filter_start)],
        states       = {
            KEYWORD:    [MessageHandler(filters.TEXT & ~filters.COMMAND, filter_keyword)],
            LOCATION:   [MessageHandler(filters.TEXT & ~filters.COMMAND, filter_location)],
            EXPERIENCE: [MessageHandler(filters.TEXT & ~filters.COMMAND, filter_experience)],
        },
        fallbacks    = [CommandHandler("cancel", filter_cancel)],
    )

    app.add_handler(CommandHandler("start",       cmd_start))
    app.add_handler(CommandHandler("stop",        cmd_stop))
    app.add_handler(CommandHandler("stats",       cmd_stats))
    app.add_handler(CommandHandler("myfilter",    cmd_myfilter))
    app.add_handler(CommandHandler("clearfilter", cmd_clearfilter))
    app.add_handler(CommandHandler("latestjobs",  cmd_latestjobs))
    app.add_handler(filter_conv)

    # Kick off the scheduler (runs inside the same event loop as the bot)
    scheduler = AsyncIOScheduler()
    scheduler.add_job(
        scheduled_scrape,
        trigger       = "interval",
        hours         = SCRAPE_INTERVAL_HOURS,
        args          = [app],
        next_run_time = datetime.now(),   # scrape immediately on startup
    )
    scheduler.start()

    logger.info("🤖 Bot is running…")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
