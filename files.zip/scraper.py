# ─────────────────────────────────────────────
#  scraper.py  —  Hahu Jobs page scraper
# ─────────────────────────────────────────────
import logging
import time

from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

from db import save_job

logger = logging.getLogger(__name__)


# ── Driver ────────────────────────────────────

def _build_driver() -> webdriver.Chrome:
    opts = Options()
    opts.add_argument("--headless")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--window-size=1920,1080")
    opts.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
    )
    return webdriver.Chrome(options=opts)


# ── Parsing helpers ───────────────────────────

def _parse_cards(soup: BeautifulSoup) -> list:
    """Find job card elements on the page."""
    cards = soup.find_all("div", class_=lambda x: x and "rounded-xl" in x and "shadow-md" in x)
    if not cards:
        # Fallback: locate cards by their h3 title elements
        cards = [
            h3.find_parent("div", class_=lambda x: x and "rounded-xl" in x)
            for h3 in soup.find_all("h3")
        ]
        cards = [c for c in cards if c]
    return cards


def _extract_job(card) -> dict | None:
    """Parse a single job card into a dict. Returns None if the card should be skipped."""
    try:
        # Title
        title_elem = card.find("h3")
        if not title_elem:
            return None
        title = title_elem.text.strip()

        # Company
        company_elem = title_elem.find_next("p")
        company = company_elem.text.strip() if company_elem else "Unknown"

        # URL
        link_elem = card.find("a", href=True)
        if not link_elem:
            return None
        job_url = "https://www.hahu.jobs" + link_elem["href"]

        # Skip expired/closed listings (no "left" in card text)
        card_text = card.get_text(separator=" ")
        if "left" not in card_text.lower():
            return None

        # Deadline
        deadline_elem = card.find(
            lambda t: t.name in ["p", "span"] and "left" in t.text.lower()
        )
        deadline = deadline_elem.text.strip() if deadline_elem else "Active"

        # Location & Experience
        info_elems = card.find_all(
            ["p", "span"],
            class_=lambda x: x and ("text-gray-600" in x or "text-sm" in x)
        )
        details   = [el.text.strip() for el in info_elems if len(el.text.strip()) < 50]
        location   = details[2] if len(details) >= 3 else "N/A"
        experience = details[3] if len(details) >= 4 else "N/A"

        # Description snippet
        desc_elem   = card.find("p", class_="line-clamp-3")
        description = desc_elem.text.strip() if desc_elem else ""

        return {
            "title":       title,
            "company":     company,
            "location":    location,
            "experience":  experience,
            "description": description,
            "deadline":    deadline,
            "url":         job_url,
        }
    except Exception:
        return None


# ── Public API ────────────────────────────────

def scrape_page(url: str) -> list[dict]:
    """Scrape a single page. Returns a list of newly-saved job dicts."""
    driver = _build_driver()
    new_jobs: list[dict] = []

    try:
        logger.info(f"Scraping: {url}")
        driver.get(url)
        time.sleep(7)  # wait for JS to render

        soup  = BeautifulSoup(driver.page_source, "html.parser")
        cards = _parse_cards(soup)
        logger.info(f"  Found {len(cards)} cards")

        for card in cards:
            job = _extract_job(card)
            if job is None:
                continue
            is_new = save_job(
                job["title"], job["company"], job["location"],
                job["experience"], job["description"], job["deadline"], job["url"]
            )
            if is_new:
                new_jobs.append(job)

    except Exception as e:
        logger.error(f"Error scraping {url}: {e}")
    finally:
        driver.quit()

    return new_jobs


def scrape_all_pages(start_page: int, end_page: int, base_url: str) -> list[dict]:
    """Scrape a range of pages and return all newly-found jobs."""
    all_new: list[dict] = []

    for i in range(start_page, end_page + 1):
        try:
            new = scrape_page(base_url + str(i))
            all_new.extend(new)
            logger.info(f"Page {i}: {len(new)} new jobs")
        except Exception as e:
            logger.error(f"Page {i} failed: {e}")

    logger.info(f"Scrape complete — {len(all_new)} total new jobs")
    return all_new
