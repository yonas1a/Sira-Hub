# ─────────────────────────────────────────────
#  config.py  —  Edit these values before running
# ─────────────────────────────────────────────

# 1. Get your token from @BotFather on Telegram
BOT_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN_HERE"

# 2. Scraping schedule
SCRAPE_INTERVAL_HOURS = 3        # How often to scrape (in hours)
START_PAGE             = 1       # First page to scrape
END_PAGE               = 20      # Last page to scrape

# 3. Target URL (page number is appended automatically)
BASE_URL = "https://www.hahu.jobs/jobs?min_yoe=0&max_yoe=100&page="

# 4. Database file path
DB_PATH = "jobs.db"

# 5. Max jobs sent per alert per user (prevents Telegram flood)
MAX_JOBS_PER_ALERT = 10
