# ─────────────────────────────────────────────
#  db.py  —  All database operations
# ─────────────────────────────────────────────
import sqlite3
from config import DB_PATH


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


# ── Schema ────────────────────────────────────

def init_db():
    """Create all tables if they don't already exist."""
    with _conn() as conn:
        conn.executescript('''
            CREATE TABLE IF NOT EXISTS jobs (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                title       TEXT,
                company     TEXT,
                location    TEXT,
                experience  TEXT,
                description TEXT,
                deadline    TEXT,
                url         TEXT UNIQUE,
                scraped_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS subscribers (
                chat_id   INTEGER PRIMARY KEY,
                username  TEXT,
                joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                active    INTEGER DEFAULT 1
            );

            CREATE TABLE IF NOT EXISTS filters (
                chat_id    INTEGER PRIMARY KEY,
                keyword    TEXT,
                location   TEXT,
                experience TEXT,
                FOREIGN KEY(chat_id) REFERENCES subscribers(chat_id)
            );
        ''')


# ── Jobs ─────────────────────────────────────

def save_job(title, company, location, experience, description, deadline, url) -> bool:
    """Insert a job. Returns True if new, False if duplicate."""
    try:
        with _conn() as conn:
            conn.execute(
                '''INSERT INTO jobs
                   (title, company, location, experience, description, deadline, url)
                   VALUES (?, ?, ?, ?, ?, ?, ?)''',
                (title, company, location, experience, description, deadline, url)
            )
        return True
    except sqlite3.IntegrityError:
        return False


def search_jobs(keyword=None, location=None, experience=None, limit=10) -> list:
    """Return jobs filtered by the given criteria, newest first."""
    query  = "SELECT title, company, location, experience, description, deadline, url FROM jobs WHERE 1=1"
    params = []

    if keyword:
        query += " AND (title LIKE ? OR description LIKE ? OR company LIKE ?)"
        kw = f"%{keyword}%"
        params.extend([kw, kw, kw])
    if location:
        query += " AND location LIKE ?"
        params.append(f"%{location}%")
    if experience:
        query += " AND experience LIKE ?"
        params.append(f"%{experience}%")

    query += " ORDER BY scraped_at DESC LIMIT ?"
    params.append(limit)

    with _conn() as conn:
        return [dict(row) for row in conn.execute(query, params)]


def get_stats() -> dict:
    with _conn() as conn:
        total   = conn.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
        today   = conn.execute("SELECT COUNT(*) FROM jobs WHERE DATE(scraped_at) = DATE('now')").fetchone()[0]
        subs    = conn.execute("SELECT COUNT(*) FROM subscribers WHERE active = 1").fetchone()[0]
    return {"total_jobs": total, "jobs_today": today, "active_subscribers": subs}


# ── Subscribers ───────────────────────────────

def add_subscriber(chat_id: int, username: str):
    with _conn() as conn:
        conn.execute(
            "INSERT INTO subscribers (chat_id, username, active) VALUES (?, ?, 1) "
            "ON CONFLICT(chat_id) DO UPDATE SET active = 1, username = excluded.username",
            (chat_id, username)
        )


def remove_subscriber(chat_id: int):
    with _conn() as conn:
        conn.execute("UPDATE subscribers SET active = 0 WHERE chat_id = ?", (chat_id,))


def get_active_subscribers() -> list[int]:
    with _conn() as conn:
        rows = conn.execute("SELECT chat_id FROM subscribers WHERE active = 1").fetchall()
    return [r[0] for r in rows]


# ── Filters ───────────────────────────────────

def upsert_filter(chat_id: int, keyword=None, location=None, experience=None):
    with _conn() as conn:
        conn.execute(
            '''INSERT INTO filters (chat_id, keyword, location, experience) VALUES (?, ?, ?, ?)
               ON CONFLICT(chat_id) DO UPDATE SET
                   keyword    = excluded.keyword,
                   location   = excluded.location,
                   experience = excluded.experience''',
            (chat_id, keyword, location, experience)
        )


def get_filter(chat_id: int) -> dict | None:
    with _conn() as conn:
        row = conn.execute(
            "SELECT keyword, location, experience FROM filters WHERE chat_id = ?", (chat_id,)
        ).fetchone()
    return dict(row) if row else None


def clear_filter(chat_id: int):
    with _conn() as conn:
        conn.execute("DELETE FROM filters WHERE chat_id = ?", (chat_id,))
